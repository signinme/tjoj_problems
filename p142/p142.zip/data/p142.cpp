/**
 * @name    p142.cpp
 * @brief   p142样例程序
 * @date    2022-12-02
*/

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>
using namespace std;

/********************************/
/*     以下是你需要提交的代码     */
/********************************/
class FreqStack {
private:
    struct item {
        int val, index, nums;
        item(int v = 0, int i = 0, int n = 0) : val(v), index(i), nums(n) {}
    };
    struct COMP {
        bool operator()(const item &i1, const item &i2) {
            if( i1.nums != i2.nums ) {
                return i2.nums > i1.nums;
            }
            return i2.index > i1.index;
        }
    };

    std::priority_queue<item, std::vector<item>, COMP> pque;
    std::map<int, int> chart;
    int index;
public:
    FreqStack() : index(0) {}
    
    void push(int val) {
        pque.push(item(val, index ++, chart[val] ++));
    }
    
    int pop() {
        item i = pque.top();
        pque.pop();
        chart[i.val] --;
        return i.val;
    }
};
/********************************/
/*     以上是你需要提交的代码     */
/********************************/

int main() {
    int n;
    std::cin >> n;
    FreqStack fs;
    while (n --) {
        std::string order;
        std::cin >> order;
        if (order == "push") {
            int val;
            std::cin >> val;
            fs.push(val);
        }
        else if (order == "pop") {
            std::cout << fs.pop() << std::endl;
        }
    }
    return 0;
}
