/**
 * @name    p140.cpp
 * @brief   p140样例程序
 * @date    2022-11-26
*/

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>

class Solution {
public:
    /**
     * @brief   单源最短路
    */
    void minimumSpanningTree(const std::vector<std::vector<std::pair<int, int>>> &edges, std::vector<int> &min_distance, int n) {
        struct COMP {
            bool operator()(const std::pair<int, int> &p1, const std::pair<int, int> &p2) {
                return p1.second > p2.second;
            }
        };
        std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, COMP> pque;
        pque.push(std::make_pair(0, 0));
        while( ! pque.empty() ) {
            std::pair<int, int> now = pque.top();
            pque.pop();
            if( min_distance[now.first] != -1 ) {
                continue;
            }
            min_distance[now.first] = now.second;
            for( auto &next : edges[now.first] ) {
                if( min_distance[next.first] == -1 ) {
                    pque.push(std::make_pair(next.first, now.second + next.second));
                }
            }
        }
    }
    int reachableNodes(std::vector<std::vector<int>>& edges, int maxMoves, int n) {
        // 这里填写你的代码 
        std::vector<std::vector<std::pair<int, int>>> reshaped_edges(n);
        for( int i = 0; i < edges.size(); i ++ ) {
            reshaped_edges[edges[i][0]].emplace_back(edges[i][1], edges[i][2] + 1);
            reshaped_edges[edges[i][1]].emplace_back(edges[i][0], edges[i][2] + 1);
        }
        std::vector<int> min_distance(n, -1);
        minimumSpanningTree(reshaped_edges, min_distance, n);
        int ans = 0;
        for( int i = 0; i < n; i ++ ) {
            if( min_distance[i] == -1 )
                min_distance[i] = maxMoves + 1;
            if( min_distance[i] <= maxMoves ) {
                ans ++;
            }
        }
        for( auto &edge : edges ) {
            ans += std::min(edge[2],
                std::min(edge[2], std::max(0, maxMoves - min_distance[edge[0]])) +
                std::min(edge[2], std::max(0, maxMoves - min_distance[edge[1]]))
            );
        }
        return ans;
    }
};
int main() {
    int n, m, maxMoves;
    std::cin >> n >> m >> maxMoves;
    std::vector<std::vector<int>> edges(m, std::vector<int>(3));
    for (int i = 0; i < m; i ++) {
        std::cin >> edges[i][0] >> edges[i][1] >> edges[i][2];
    }
    Solution s;
    std::cout << s.reachableNodes(edges, maxMoves, n) << std::endl;
    return 0;
}
