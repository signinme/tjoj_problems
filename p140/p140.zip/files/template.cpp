/**
 * @name    p140.cpp
 * @brief   p140模板程序
 * @date    2022-11-26
*/

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>
using namespace std;

/********************************/
/*     以下是你需要提交的代码     */
/********************************/
class Solution {
public:
    int reachableNodes(std::vector<std::vector<int>>& edges, int maxMoves, int n) {
        // 这里填写你的代码

    }
};
/********************************/
/*     以上是你需要提交的代码     */
/********************************/

int main() {
    int n, m, maxMoves;
    std::cin >> n >> m >> maxMoves;
    std::vector<std::vector<int>> edges(m, std::vector<int>(3));
    for (int i = 0; i < n; i ++) {
        std::cin >> edges[i][0] >> edges[i][1] >> edges[i][2];
    }
    Solution s;
    std::cout << s.reachableNodes(edges, maxMoves, n) << std::endl;
    return 0;
}
