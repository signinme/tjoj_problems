/**
 * @name    p140_data.cpp
 * @brief   p140随机测试数据生成程序
 * @date    2022-11-26
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <queue>
#include <set>

class Solution {
private:
    std::vector<std::vector<int>> edges_list;
    std::vector<std::vector<std::pair<int, int>>> edges;
    std::vector<int> min_distance;

public:
    /**
     * @param n     点个数
     * @param m     边条数
     * @param mean  分割数均值
     * @param epsilon 分割数范围
     * @brief       分割数在[min(max,mean-epsilon),min(mean+epsilon,10000)]上均匀采样
    */
    Solution(int n, int m, int mean, int epsilon) : edges_list(m, std::vector<int>(3)), edges(n), min_distance(n, -1) {
        mean = std::max(0, mean - epsilon);
        epsilon *= 2;
        std::vector<int> last_num(n, n - 1);
        std::vector<std::vector<bool>> chart(n, std::vector<bool>(n, true));
        int bound = n * n;
        for (int i = 0; i < m; i ++ ) {
            int x = rand() % n;
            while( last_num[x] == 0 ) {
                x = rand() % n;
            }
            int j = rand() % last_num[x], y = 0;
            while( true ) {
                if( x != y && chart[x][y] == true ) {
                    if( !j ) {
                        break;
                    }
                    j--;
                }
                y++;
            }
            chart[x][y] = chart[y][x] = false;
            last_num[x]--;
            last_num[y]--;
            int num = std::min(rand() % epsilon + mean + 1, 10000);
            edges_list[i][0] = x;
            edges_list[i][1] = y;
            edges_list[i][2] = num;
            edges[x].emplace_back(y, num + 1);
            edges[y].emplace_back(x, num + 1);
        }
    }
    /**
     * @brief   单源最短路
    */
    void minimumSpanningTree() {
        struct COMP {
            bool operator()(const std::pair<int, int> &p1, const std::pair<int, int> &p2) {
                return p1.second > p2.second;
            }
        };
        int n = edges.size();
        std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, COMP> pque;
        pque.push(std::make_pair(0, 0));
        while( ! pque.empty() ) {
            std::pair<int, int> now = pque.top();
            pque.pop();
            if( min_distance[now.first] != -1 ) {
                continue;
            }
            min_distance[now.first] = now.second;
            for( auto &next : edges[now.first] ) {
                if( min_distance[next.first] == -1 ) {
                    pque.push(std::make_pair(next.first, now.second + next.second));
                }
            }
        }
    }
    /**
     * @brief   计算可到点个数
    */
    int reachableNodes(int maxMoves) {
        minimumSpanningTree();
        int ans = 0, n = edges.size();
        for( int i = 0; i < n; i ++ ) {
            if( min_distance[i] == -1 ) {
                min_distance[i] = maxMoves + 1;
            }
            if( min_distance[i] <= maxMoves ) {
                ans ++;
            }
        }
        for( auto &edge : edges_list ) {
            ans += std::min(edge[2],
                std::min(edge[2], std::max(0, maxMoves - min_distance[edge[0]])) +
                std::min(edge[2], std::max(0, maxMoves - min_distance[edge[1]]))
            );
        }
        return ans;
    }
    /**
     * @brief   打印边
    */
    void printEgdes(std::ostream &out) {
        for( auto &edge : edges_list ) {
            out << edge[0] << ' ' << edge[1] << ' ' << edge[2] << std::endl;
        }
    }
};
int main()
{
    srand((unsigned)time(NULL));
    int test_num = 10; // 测试点个数
    for( int index = 1; index <= test_num; index ++ ) {
        std::string input_file = "input" + std::to_string(index) + ".txt";
        std::string output_file = "output" + std::to_string(index) + ".txt";
        std::ofstream fin(input_file.c_str());
        std::ofstream fout(output_file.c_str());

        int n, m, mean, epsilon, maxMoves;
        if( index <= test_num * 0.2 ) {
            n = rand() % 6 + 5;
        }
        else if( index <= test_num * 0.4 ) {
            n = rand() % 11 + 90;
        }
        else {
            n = rand() % 51 + 2950;
        }
        m = std::min(rand() % (n * (n - 1) / 2 + 1), 10000);
        mean = rand() % 5000;
        epsilon = rand() % 5000;
        maxMoves = rand() % std::min(mean * n, 1000000000);
        // 文件输出代码
        Solution s(n, m, mean, epsilon);
        fin << n << ' ' << m << ' ' << maxMoves << std::endl;
        s.printEgdes(fin);
        fout << s.reachableNodes(maxMoves) << std::endl;

        fin.close();
        fout.close();
    }
}
