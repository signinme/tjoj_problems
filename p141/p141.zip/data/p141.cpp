/**
 * @name    p141.cpp
 * @brief   p141样例程序
 * @date    2022-11-30
*/

#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>

class Sequence {
private:
public:
    void solve(const std::vector<std::vector<int>> &nums, std::vector<int> &ans) {
        int m = nums.size(), n = nums[0].size();
        ans.resize(n);
        for (int i = 0; i < n; i ++) {
            ans[i] = nums[0][i];
        }
        std::sort(ans.begin(), ans.end());
        for (int i = 1; i < m; i ++) {
            // 堆
            std::priority_queue<int> pque;
            for (int j = 0; j < n; j++) {
                pque.push(nums[i][0] + ans[j]);
            }
            for (int z = 1; z < n; z ++) {
                for (int j = 0; j < n; j ++) {
                    if (ans[j] + nums[i][z] < pque.top()) {
                        pque.pop();
                        pque.push(ans[j] + nums[i][z]);
                    }
                    else {
                        break;
                    }
                }
            }
            for (int j = 1; j <= n; j ++) {
                ans[n - j] = pque.top();
                pque.pop();
            }
        }
    }
};

int main() {
    int T;
    Sequence S;
    std::cin >> T;
    while (T --) {
        int n, m;
        std::cin >> m >> n;
        std::vector<std::vector<int>> nums(m, std::vector<int>(n));
        for (int i = 0; i < m; i ++) {
            for (int j = 0; j < n; j ++) {
                std::cin >> nums[i][j];
            }
        }
        std::vector<int> ans;
        S.solve(nums, ans);
        for (int i = 0; i < n - 1; i ++) {
            std::cout << ans[i] << ' ';
        }
        std::cout << ans[n - 1] << std::endl;
    }
    return 0;
}