/**
 * @file    p139.cpp
 * @name    p139样例程序
 * @date    2022-11-22
*/

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>
using namespace std;

class Solution {
public:
    std::string largestNumber(std::vector<int>& nums) {
        int n = nums.size();
        std::vector<std::string> list(n);
        for( int i = 0; i < n; i ++ )
            list[i] = std::to_string(nums[i]);
        auto comp = [](const std::string &s1, const std::string &s2) {
            int n1 = s1.length(), n2 = s2.length();
            for( int i = 0; i < n1 + n2; i ++ ) {
                char c1 = (i < n1 ? s1[i] : s2[i - n1]);
                char c2 = (i < n2 ? s2[i] : s1[i - n2]);
                if( c1 != c2 )
                    return c1 > c2;
            }
            return false;
        };
        std::sort(list.begin(), list.end(), comp);
        std::string ans;
        for( int i = 0; i < n; i ++ ) {
            ans += list[i];
        }
        int i = 0;
        while( i < ans.length() - 1 && ans[i] == '0' )
            i ++;
        return ans.substr(i);
    }
};

int main() {
    int n;
    std::cin >> n;
    std::vector<int> nums(n);
    for (int i = 0; i < n; i ++ ) {
        std::cin >> nums[i];
    }
    Solution s;
    std::cout << s.largestNumber(nums) << std::endl;
    return 0;
}