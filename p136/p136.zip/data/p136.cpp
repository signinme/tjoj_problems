/**
 * @file    p136.cpp
 * @name    p136样例程序
 * @date    2022-11-10
*/

#include <iostream>
#include <vector>
#include <queue>
#include <climits>

class Graph {
private:
    struct Subject {
        int time_consuming;
        int last_subjects, next_subjects;
        int min_start_time, max_start_time;
        std::vector<int> next;
        std::vector<int> last;
        Subject() : last_subjects(0), next_subjects(0), min_start_time(0), max_start_time(INT_MAX) {}
    };
    int size;
    std::vector<Subject> subjects;
public:
    Graph(int n) : size(n), subjects(n) {}

    void addSubject(int id, int time_consuming, const std::vector<int> &last) {
        subjects[id].time_consuming = time_consuming;
        subjects[id].last = last;
        subjects[id].last_subjects = last.size();
        for( auto l : last ) {
            subjects[l].next_subjects ++;
            subjects[l].next.emplace_back(id);
        }
    }

    bool calculateKeyWay() {
        std::queue<int> que;
        int count = 0;
        for( int i = 0; i < size; i ++ ){
            if( subjects[i].last_subjects == 0 ) {
                que.push(i);
            }
        }
        int end_time = 0;
        while( count < size && !que.empty() ) {
            int now = que.front();
            que.pop();
            count ++;
            int now_end_time = subjects[now].min_start_time + subjects[now].time_consuming;
            end_time = std::max(end_time, now_end_time);
            for( auto next : subjects[now].next ) {
                subjects[next].last_subjects --;
                subjects[next].min_start_time = std::max(subjects[next].min_start_time, now_end_time);
                if( subjects[next].last_subjects == 0 ) {
                    que.push(next);
                }
            }
        }
        if( count != size || !que.empty() ) {
            return false;
        }
        
        for( int i = 0; i < size; i ++ ) {
            if( subjects[i].next_subjects == 0 ) {
                subjects[i].max_start_time = end_time - subjects[i].time_consuming;
                que.push(i);
            }
        }
        while( count && !que.empty() ) {
            int now = que.front();
            que.pop();
            count --;
            for( auto last : subjects[now].last ) {
                subjects[last].next_subjects --;
                subjects[last].max_start_time = std::min(subjects[last].max_start_time, subjects[now].max_start_time - subjects[last].time_consuming );
                if( subjects[last].next_subjects == 0 ) {
                    que.push(last);
                }
            }
        }
        if( count != 0 || !que.empty() )
            return false;
        return true;
    }

    void printAns(std::ostream &out) {
        for( int i = 0; i < size; i ++ ) {
            out << subjects[i].min_start_time + subjects[i].time_consuming << ' ';
            if( subjects[i].min_start_time == subjects[i].max_start_time )
                out << 1 << std::endl;
            else
                out << 0 << std::endl;
        }
    }
};
int main() {
    int n;
    std::cin >> n;
    Graph g(n);
    for( int i = 0; i < n; i ++ ) {
        int time_consuming, m;
        std::cin >> time_consuming >> m;
        std::vector<int> last(m);
        for( int j = 0; j < m; j ++ ) {
            std::cin >> last[j];
            last[j] --;
        }
        g.addSubject(i, time_consuming, last);
    }
    if( g.calculateKeyWay() ) {
        g.printAns(std::cout);
    }
    return 0;
}