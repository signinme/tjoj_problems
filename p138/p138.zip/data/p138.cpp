/**
 * @file    p138.cpp
 * @name    p138样例程序
 * @date    2022-11-20
*/

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>
using namespace std;


/********************************/
/*     以下是你需要提交的代码     */
/********************************/
class Solution {
public:
    int solve(std::vector<vector<std::string>> &old_chart, std::vector<std::vector<std::string>> &new_chart) {
        // 这里填写你的代码
        int n = old_chart.size();
        int m = old_chart[0].size();
        std::map<std::string, int> index_chart;
        for( int i = 0; i < n; i ++ ) {
            for( int j = 0; j < m; j ++ ) {
                index_chart[old_chart[i][j]] = i * m + j;
            }
        }
        std::vector<bool> bo(n * m, false);
        int count = 0;
        for( int i = 0; i < n; i ++ ) {
            for( int j = 0; j < m; j ++ ) {
                if( bo[i * m + j] == true ) {
                    continue;
                }
                bo[i * m + j] = true;
                count ++;
                int next = index_chart[new_chart[i][j]];
                while( next != i * m + j ) {
                    bo[next] = true;
                    next = index_chart[new_chart[next / m][next % m]];
                }
            }
        }
        return n * m - count;
    }
};
/********************************/
/*     以上是你需要提交的代码     */
/********************************/

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<std::string>> old_chart(n, std::vector<std::string>(m));
    std::vector<std::vector<std::string>> new_chart(n, std::vector<std::string>(m));

    for( int i = 0; i < n; i ++ ) {
        for( int j = 0; j < m; j ++ ) {
            std::cin >> old_chart[i][j];
        }
    }
    for( int i = 0; i < n; i ++ ) {
        for( int j = 0; j < m; j ++ ) {
            std::cin >> new_chart[i][j];
        }
    }

    Solution s;
    std::cout << s.solve(old_chart, new_chart) << std::endl;
    return 0;
}
